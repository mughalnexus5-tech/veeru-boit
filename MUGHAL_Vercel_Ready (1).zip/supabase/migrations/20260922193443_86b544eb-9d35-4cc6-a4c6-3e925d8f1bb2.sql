CREATE TABLE public.licenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  activated_at timestamptz,
  expires_at timestamptz,
  device_limit integer NOT NULL DEFAULT 1,
  notes text NOT NULL DEFAULT '',
  last_activity timestamptz
);

CREATE TABLE public.license_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_id uuid NOT NULL REFERENCES public.licenses(id) ON DELETE CASCADE,
  device_id text NOT NULL,
  label text NOT NULL DEFAULT '',
  first_seen timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  UNIQUE (license_id, device_id)
);

CREATE INDEX idx_license_devices_license ON public.license_devices(license_id);

GRANT ALL ON public.licenses TO service_role;
GRANT ALL ON public.license_devices TO service_role;

ALTER TABLE public.licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.license_devices ENABLE ROW LEVEL SECURITY;

INSERT INTO public.licenses (license_key, status, device_limit, notes, expires_at)
VALUES ('Veer_vip_bot_FX93', 'active', 0, 'Legacy master key — lifetime, unlimited devices', NULL);