import * as d from "react";
import * as e from "react/jsx-runtime";
import logoAsset from "./assets/veerubot-logo.png.asset.json";
import { verifyLicenseKey } from "./lib/license.functions";
export const WHATSAPP_URL = "https://whatsapp.com/channel/0029Vb8LQYyLdQebuuDIEA2m";
const w = logoAsset.url,
  E = "https://i.postimg.cc/9fbFbQHz/quotex.webp",
  T = "https://i.postimg.cc/zBWNMz9C/pocketoption-2.jpg",
  I = [
    "EUR/USD",
    "GBP/USD",
    "USD/JPY",
    "EUR/GBP",
    "EUR/JPY",
    "GBP/JPY",
    "AUD/USD",
    "USD/CAD",
    "USD/CHF",
    "NZD/USD",
  ],
  M = [
    "EUR/USD OTC",
    "GBP/USD OTC",
    "USD/JPY OTC",
    "USD/CHF OTC",
    "USD/CAD OTC",
    "AUD/USD OTC",
    "NZD/USD OTC",
    "AUD/CAD OTC",
    "AUD/NZD OTC",
    "CAD/CHF OTC",
  ],
  R = [
    "EUR/GBP OTC",
    "EUR/JPY OTC",
    "GBP/JPY OTC",
    "AUD/JPY OTC",
    "EUR/AUD OTC",
    "GBP/AUD OTC",
    "CHF/JPY OTC",
    "EUR/CHF OTC",
    "EUR/CAD OTC",
    "GBP/CAD OTC",
    "GBP/CHF OTC",
    "CAD/JPY OTC",
    "NZD/JPY OTC",
    "NZD/CAD OTC",
  ],
  _ = [
    "USD/PKR OTC",
    "USD/INR OTC",
    "USD/IDR OTC",
    "USD/BRL OTC",
    "USD/BDT OTC",
    "USD/NGN OTC",
    "USD/PHP OTC",
    "USD/EGP OTC",
    "USD/TRY OTC",
    "USD/ZAR OTC",
    "USD/MXN OTC",
    "USD/ARS OTC",
    "USD/COP OTC",
    "USD/CLP OTC",
    "USD/VND OTC",
    "USD/THB OTC",
    "USD/MYR OTC",
    "USD/SGD OTC",
    "USD/RUB OTC",
    "USD/DZD OTC",
    "EUR/TRY OTC",
    "EUR/HUF OTC",
    "EUR/PLN OTC",
    "EUR/NOK OTC",
    "EUR/SEK OTC",
    "USD/NOK OTC",
    "USD/SEK OTC",
    "USD/CNH OTC",
  ],
  Z = [
    "GOLD OTC",
    "SILVER OTC",
    "BRENT OIL OTC",
    "WTI OIL OTC",
    "BITCOIN OTC",
    "ETHEREUM OTC",
  ],
  C = [
    "EUR/USD",
    "USD/JPY",
    "GBP/USD",
    "USD/CHF",
    "AUD/USD",
    "USD/CAD",
    "NZD/USD",
    "EUR/JPY",
    "GBP/JPY",
    "EUR/GBP",
  ],
  C2 = [
    "AUD/JPY",
    "CHF/JPY",
    "CAD/JPY",
    "EUR/AUD",
    "EUR/CAD",
    "EUR/CHF",
    "EUR/NZD",
    "GBP/AUD",
    "GBP/CAD",
    "GBP/CHF",
    "GBP/NZD",
    "AUD/NZD",
    "AUD/CAD",
    "AUD/CHF",
    "NZD/JPY",
    "NZD/CAD",
    "NZD/CHF",
    "CAD/CHF",
  ],
  C3 = [
    "XAU/USD",
    "XAG/USD",
    "XPT/USD",
    "BRENT OIL",
    "WTI OIL",
    "NATURAL GAS",
    "BTC/USD",
    "ETH/USD",
    "BNB/USD",
    "SOL/USD",
    "XRP/USD",
    "DOGE/USD",
    "LTC/USD",
    "US30",
    "NAS100",
    "SP500",
    "GER40",
    "UK100",
    "JPN225",
    "HK50",
  ],
  C4 = [
    "USD/TRY",
    "USD/MXN",
    "USD/ZAR",
    "USD/SGD",
    "USD/HKD",
    "USD/CNH",
    "USD/PLN",
    "USD/NOK",
    "USD/SEK",
    "USD/HUF",
    "USD/INR",
    "USD/THB",
    "EUR/TRY",
    "EUR/PLN",
    "EUR/NOK",
    "EUR/SEK",
    "EUR/HUF",
    "GBP/SGD",
  ],
  P = ["5s", "10s", "15s", "30s", "45s", "1m", "2m", "3m", "5m", "15m"],
  PL = ["1m", "2m", "3m", "5m", "10m", "15m", "30m", "1h", "2h", "4h"];
function ee() {
  const [t, s] = d.useState("boot"),
    [a, r] = d.useState("quotex"),
    [m, o] = d.useState(null),
    [c, i] = d.useState(null),
    [x, u] = d.useState(null),
    [l, n] = d.useState(null),
    [p, h] = d.useState(null),
    [mk, setMk] = d.useState("otc");
  d.useEffect(() => {
    let alive = true;
    (async () => {
      let saved = null;
      try {
        saved = localStorage.getItem("veerubot_license_key");
        const exp = localStorage.getItem("veerubot_license_exp");
        if (exp && Date.parse(exp) && Date.parse(exp) <= Date.now()) {
          localStorage.removeItem("veerubot_license_key");
          localStorage.removeItem("veerubot_license_exp");
          saved = null;
        }
      } catch {}
      if (!saved) {
        alive && s("gate");
        return;
      }
      try {
        const res = await verifyLicenseKey({
          data: { key: saved, deviceId: deviceId() },
        });
        if (!alive) return;
        if (res.ok) {
          try {
            if (res.expiresAt)
              localStorage.setItem("veerubot_license_exp", String(res.expiresAt));
            else localStorage.removeItem("veerubot_license_exp");
          } catch {}
          s("dashboard");
        } else {
          try {
            localStorage.removeItem("veerubot_license_key");
            localStorage.removeItem("veerubot_license_exp");
          } catch {}
          s("gate");
        }
      } catch {
        alive && s("gate");
      }
    })();
    return () => {
      alive = false;
    };
  }, []);
  return e.jsxs("div", {
    className: "min-h-screen relative overflow-hidden",
    children: [
      e.jsx(B, {}),
      t === "boot" &&
        e.jsx("div", {
          className:
            "relative z-10 min-h-screen flex flex-col items-center justify-center gap-4",
          children: [
            e.jsx(
              "div",
              {
                className:
                  "w-14 h-14 rounded-full border-2 border-[var(--gold)]/30 border-t-[var(--gold)] animate-spin-slow",
              },
              "sp",
            ),
            e.jsx(
              "div",
              {
                className:
                  "text-[11px] tracking-[0.3em] text-muted-foreground uppercase",
                children: "Verifying device…",
              },
              "tx",
            ),
          ],
        }),
      t === "gate" && e.jsx(G, { onSuccess: () => s("dashboard") }),

      t === "dashboard" &&
        e.jsx(V, {
          activeBroker: a,
          setActiveBroker: r,
          qxAsset: m,
          setQxAsset: o,
          qxTime: c,
          setQxTime: i,
          poAsset: x,
          setPoAsset: u,
          poTime: l,
          setPoTime: n,
          market: mk,
          setMarket: (f) => {
            (setMk(f), o(null), i(null), u(null), n(null));
          },
          onGenerate: () => s("analysis"),
        }),
      t === "analysis" &&
        e.jsx(W, {
          asset: (a === "quotex" ? m : x) || "EUR/USD",
          time: (a === "quotex" ? c : l) || "1m",
          onComplete: (g, v) => {
            (h({
              dir: g,
              asset: (a === "quotex" ? m : x) || "EUR/USD",
              time: (a === "quotex" ? c : l) || "1m",
              market: mk,
              winRate: v,
            }),
              s("signal"));
          },
        }),
      t === "signal" &&
        p &&
        e.jsx(X, {
          signal: p,
          onReset: () => {
            (h(null), s("dashboard"));
          },
        }),
    ],
  });
}
function B() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("div", {
        className: "fixed inset-0 pointer-events-none opacity-30 grid-bg",
      }),
      e.jsx("div", {
        className:
          "fixed -top-40 -left-40 w-[500px] h-[500px] rounded-full pointer-events-none",
        style: {
          background:
            "radial-gradient(circle, oklch(0.80 0.12 85 / 0.18), transparent 70%)",
          filter: "blur(40px)",
        },
      }),
      e.jsx("div", {
        className:
          "fixed -bottom-40 -right-40 w-[600px] h-[600px] rounded-full pointer-events-none",
        style: {
          background:
            "radial-gradient(circle, oklch(0.5 0.18 200 / 0.12), transparent 70%)",
          filter: "blur(50px)",
        },
      }),
    ],
  });
}
function L({ className: t = "w-4 h-4" }) {
  return e.jsx("svg", {
    className: t,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true",
    children: e.jsx("path", {
      d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z",
    }),
  });
}
function y({ className: t = "" }) {
  return e.jsxs("a", {
    href: "https://wa.me/923321841400",
    target: "_blank",
    rel: "noopener noreferrer",
    className: `inline-flex items-center gap-1.5 text-emerald-glow font-semibold hover:underline ${t}`,
    children: [
      "HK CODER",
      e.jsx("span", {
        className:
          "inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#25D366] text-white shadow-[0_0_8px_rgba(37,211,102,0.5)]",
        children: e.jsx(L, { className: "w-3 h-3" }),
      }),
    ],
  });
}
function deviceId() {
  try {
    let v = localStorage.getItem("veerubot_device_id");
    if (!v) {
      v =
        (globalThis.crypto && globalThis.crypto.randomUUID
          ? globalThis.crypto.randomUUID()
          : String(Date.now()) + Math.random().toString(36).slice(2)) + "";
      localStorage.setItem("veerubot_device_id", v);
    }
    return v;
  } catch {
    return "no-storage-" + Math.random().toString(36).slice(2);
  }
}
function G({ onSuccess: t }) {
  const [key, setKey] = d.useState(""),
    [state, setState] = d.useState("idle"),
    [msg, setMsg] = d.useState(""),
    submit = async () => {
      if (!key.trim() || state === "verifying" || state === "success") return;
      setState("verifying");
      try {
        const res = await verifyLicenseKey({
          data: { key: key.trim(), deviceId: deviceId() },
        });
        if (res.ok) {
          try {
            localStorage.setItem("veerubot_license_key", key.trim());
            if (res.expiresAt)
              localStorage.setItem("veerubot_license_exp", String(res.expiresAt));
            else localStorage.removeItem("veerubot_license_exp");
          } catch {}
          setState("success");
          setTimeout(() => t(), 900);
        } else {
          try {
            localStorage.removeItem("veerubot_license_key");
            localStorage.removeItem("veerubot_license_exp");
          } catch {}

          setMsg(res.reason || "ACCESS DENIED");
          setState("error");
          setTimeout(() => setState("idle"), 1800);
        }
      } catch {
        setMsg("CONNECTION ERROR — TRY AGAIN");
        setState("error");
        setTimeout(() => setState("idle"), 1800);
      }
    };
  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-5 py-10 animate-fade-slide">
      <div className="w-full max-w-md glass-card rounded-3xl p-7 sm:p-9 relative">
        <div className="flex flex-col items-center">
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 flex items-center justify-center animate-float-y">
            <div
              className="absolute inset-0 rounded-full animate-spin-slow"
              style={{
                background:
                  "conic-gradient(from 0deg, transparent, var(--gold) 30%, var(--emerald-glow) 45%, transparent 55%)",
                filter: "blur(2px)",
              }}
            />
            <div className="absolute inset-2 rounded-full glass-card animate-breathe" />
            <img
              src={w}
              alt="VEERUBOT"
              className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full object-cover ring-1 ring-[var(--gold)]/50 drop-shadow-[0_8px_26px_rgba(245,184,51,0.35)]"
            />
          </div>
          <h1
            className="mt-6 text-3xl sm:text-4xl font-extrabold tracking-tight"
            style={{
              background: "linear-gradient(135deg, var(--gold-soft), var(--gold) 60%, #c07d11)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
            }}
          >
            VEERUBOT
          </h1>
          <p className="mt-1.5 text-[11px] uppercase tracking-[0.35em] text-emerald-glow font-semibold">
            Premium VIP Access
          </p>
          <div className={`mt-7 w-full ${state === "error" ? "animate-shake" : ""}`}>
            <div
              className={`relative rounded-2xl transition-all duration-300 ${
                state === "error"
                  ? "ring-2 ring-[var(--crimson)] shadow-[0_0_24px_oklch(0.7_0.26_22/0.5)]"
                  : "focus-within:ring-2 focus-within:ring-[var(--emerald-glow)] focus-within:shadow-[0_0_24px_oklch(0.78_0.22_152/0.4)]"
              }`}
            >
              <input
                type="password"
                value={key}
                onChange={(ev) => setKey(ev.target.value)}
                onKeyDown={(ev) => ev.key === "Enter" && submit()}
                placeholder="Enter MUGHAL License Key..."
                className="w-full bg-input/60 backdrop-blur rounded-2xl px-5 py-4 text-sm sm:text-base text-foreground placeholder:text-muted-foreground outline-none border border-border"
              />
            </div>
            {state === "error" && (
              <p className="mt-3 text-center text-sm font-semibold text-[var(--crimson)] tracking-wide">
                ⚠ {msg}
              </p>
            )}
            {state === "success" && (
              <p className="mt-3 text-center text-sm font-bold text-emerald-glow tracking-widest animate-fade-slide">
                ✓ VIP ACCESS VERIFIED
              </p>
            )}
            {state === "verifying" && (
              <p className="mt-3 text-center text-sm font-semibold text-emerald-glow tracking-widest">
                ⟳ Verifying secure access...
              </p>
            )}
            <button
              onClick={submit}
              disabled={state === "verifying" || state === "success"}
              className="mt-5 w-full relative overflow-hidden rounded-2xl gradient-emerald text-primary-foreground font-bold py-4 tracking-wide shine-sweep hover-lift disabled:opacity-70"
            >
              UNLOCK VIP DASHBOARD
            </button>
            <div className="mt-4">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noreferrer"
                className="block rounded-2xl py-3.5 text-center text-xs font-bold tracking-wide glass-card text-emerald-glow hover-lift"
              >
                💬 GET KEY ON WHATSAPP
              </a>
            </div>
            <p className="mt-3 text-center text-[11px] text-muted-foreground">
              Use the valid license key: MUGHAL
            </p>
          </div>
        </div>
      </div>
      <p className="mt-8 text-[11px] tracking-[0.25em] text-muted-foreground/70 uppercase">
        VEERUBOT · Premium Signal Intelligence
      </p>
    </div>
  );
}
function V(t) {
  const {
      activeBroker: s,
      setActiveBroker: a,
      qxAsset: r,
      setQxAsset: m,
      qxTime: o,
      setQxTime: c,
      poAsset: i,
      setPoAsset: x,
      poTime: u,
      setPoTime: l,
      onGenerate: n,
      market: mkt,
      setMarket: setMkt,
    } = t,
    [p, h] = d.useState(null),
    g = s === "quotex" ? r : i,
    v = s === "quotex" ? o : u,
    j = !!(g && v);
  return e.jsxs("div", {
    className: "relative z-10 min-h-screen pb-10 animate-fade-slide",
    children: [
      e.jsx(q, {}),
      e.jsx("div", {
        className: "px-4 sm:px-6 mt-4 sm:mt-6",
        children: e.jsxs("div", {
          className:
            "glass-card rounded-3xl p-5 sm:p-8 relative overflow-hidden",
          children: [
            e.jsx("div", {
              className:
                "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--emerald-glow)] to-transparent opacity-60",
            }),
            e.jsxs("div", {
              className: "flex items-center justify-between gap-3",
              children: [
                e.jsx(A, { src: E, label: "Quotex" }),
                e.jsx("div", {
                  className: "relative flex-1 flex justify-center",
                  children: e.jsxs("div", {
                    className:
                      "relative w-32 h-32 sm:w-40 sm:h-40 flex items-center justify-center animate-float-y",
                    children: [
                      e.jsx("div", {
                        className:
                          "absolute inset-0 rounded-full animate-breathe glass-card",
                      }),
                      e.jsx("div", {
                        className:
                          "absolute inset-0 rounded-full animate-spin-slow",
                        style: {
                          background:
                            "conic-gradient(from 90deg, transparent, oklch(0.80 0.12 85 / 0.45), transparent 60%)",
                          filter: "blur(3px)",
                        },
                      }),
                      e.jsx("img", {
                        src: w,
                        alt: "VEER",
                        className:
                          "relative w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover ring-2 ring-[oklch(0.80_0.12_85/0.6)] shadow-[0_0_28px_rgba(216,184,96,0.4)]",
                      }),
                    ],
                  }),
                }),
                e.jsx(A, { src: T, label: "Pocket" }),
              ],
            }),
            e.jsxs("div", {
              className:
                "mt-4 flex flex-wrap gap-2 justify-center text-[10px] sm:text-xs",
              children: [
                e.jsx(b, { color: "emerald", label: "AI Engine Connected" }),
                e.jsx(b, { color: "emerald", label: "Market Feed Synced" }),
                e.jsx(b, {
                  color: "emerald",
                  label: "Liquidity Scanner Active",
                }),
              ],
            }),
          ],
        }),
      }),
      e.jsx("div", {
        className: "px-4 sm:px-6 mt-5",
        children: e.jsx("div", {
          className: "glass-card rounded-2xl p-1.5 grid grid-cols-2 gap-1",
          children: ["quotex", "po"].map((f) =>
            e.jsx(
              "button",
              {
                onClick: () => a(f),
                className: `relative py-3 rounded-xl text-sm font-bold tracking-wide transition-all ${s === f ? "gradient-emerald text-primary-foreground shadow-[0_4px_18px_oklch(0.80_0.12_85/0.45)]" : "text-muted-foreground hover:text-foreground"}`,
                children: f === "quotex" ? "QUOTEX" : "POCKET OPTION",
              },
              f,
            ),
          ),
        }),
      }),
      e.jsx("div", {
        className: "px-4 sm:px-6 mt-3",
        children: e.jsx("div", {
          className: "glass-card rounded-2xl p-1.5 grid grid-cols-2 gap-1",
          children: ["otc", "live"].map((f) =>
            e.jsx(
              "button",
              {
                onClick: () => setMkt(f),
                className: `relative py-2.5 rounded-xl text-xs font-bold tracking-[0.2em] transition-all ${mkt === f ? "gradient-emerald text-primary-foreground shadow-[0_4px_18px_oklch(0.80_0.12_85/0.45)]" : "text-muted-foreground hover:text-foreground"}`,
                children: f === "otc" ? "OTC MARKET" : "LIVE MARKET",
              },
              f,
            ),
          ),
        }),
      }),
      e.jsx("div", {
        className: "px-4 sm:px-6 mt-2 text-center",
        children: e.jsx("p", {
          className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground",
          children:
            mkt === "otc"
              ? "OTC feed · intervals from 5 seconds"
              : "Live interbank feed · intervals from 1 minute",
        }),
      }),
      e.jsx("div", {
        className: "px-4 sm:px-6 mt-5",
        children: e.jsx($, {
          broker: s,
          logo: s === "quotex" ? E : T,
          asset: g,
          time: v,
          onOpenAssets: () => h({ kind: "asset", broker: s }),
          onOpenTime: () => h({ kind: "time", broker: s }),
        }),
      }),
      e.jsxs("div", {
        className: "px-4 sm:px-6 mt-6",
        children: [
          e.jsx("button", {
            onClick: n,
            disabled: !j,
            className: `relative w-full overflow-hidden rounded-2xl py-5 font-extrabold tracking-[0.2em] text-base sm:text-lg transition-all ${j ? "gradient-emerald text-primary-foreground animate-breathe hover-lift shine-sweep" : "bg-muted text-muted-foreground cursor-not-allowed opacity-60"}`,
            children: "⚡ GENERATE VIP SIGNAL",
          }),
          !j &&
            e.jsx("p", {
              className: "text-center text-xs text-muted-foreground mt-2",
              children: "Select an asset and timeframe to continue",
            }),
        ],
      }),
      e.jsx(F, {}),
      p &&
        e.jsx(Y, {
          kind: p.kind,
          broker: p.broker,
          market: mkt,
          currentValue:
            p.kind === "asset"
              ? p.broker === "quotex"
                ? r
                : i
              : p.broker === "quotex"
                ? o
                : u,
          onClose: () => h(null),
          onSelect: (f) => {
            (p.kind === "asset"
              ? p.broker === "quotex"
                ? m(f)
                : x(f)
              : p.broker === "quotex"
                ? c(f)
                : l(f),
              h(null));
          },
        }),
    ],
  });
}
function q() {
  return e.jsxs("header", {
    className: "px-4 sm:px-6 pt-5",
    children: [
      e.jsxs("div", {
        className:
          "glass-card rounded-2xl px-4 py-3 flex items-center justify-between gap-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5 min-w-0",
            children: [
              e.jsx("img", {
                src: w,
                 alt: "VEERUBOT",
                className:
                   "w-10 h-10 rounded-full object-cover bg-secondary p-0.5 ring-2 ring-primary shadow-[var(--shadow-glow)]",
              }),
              e.jsxs("div", {
                className: "min-w-0",
                children: [
                  e.jsx("h1", {
                    className:
                      "text-sm sm:text-base font-extrabold leading-tight truncate tracking-wide",
                    style: {
                      background:
                        "linear-gradient(135deg, var(--gold-soft), var(--gold) 60%, #c07d11)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      color: "transparent",
                    },
                    children: "VEERUBOT",
                  }),
                  e.jsx("p", {
                    className:
                      "text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-emerald-glow font-semibold",
                    children: "VIP Signal Engine",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-1.5 flex-shrink-0",
            children: [
              e.jsx(N, { dot: "emerald", children: "LIVE AI" }),
              e.jsx(N, { children: "👥 1,271" }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-2 flex flex-wrap gap-1.5",
        children: [
          e.jsx(N, { small: !0, children: "🛡 VERIFIED ENGINE" }),
          e.jsx(N, { small: !0, children: "🔐 SECURE AI ENGINE" }),
        ],
      }),
    ],
  });
}
function N({ children: t, dot: s, small: a }) {
  return e.jsxs("span", {
    className: `inline-flex items-center gap-1.5 rounded-full glass-card font-semibold tracking-wide ${a ? "px-2.5 py-1 text-[9px]" : "px-2.5 py-1.5 text-[10px] sm:text-[11px]"}`,
    children: [
      s &&
        e.jsx("span", {
          className:
            "w-1.5 h-1.5 rounded-full bg-[var(--emerald-glow)] animate-pulse-dot shadow-[0_0_8px_var(--emerald-glow)]",
        }),
      e.jsx("span", {
        className: s ? "text-emerald-glow" : "text-foreground/85",
        children: t,
      }),
    ],
  });
}
function b({ label: t }) {
  return e.jsxs("span", {
    className:
      "inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.78_0.22_152/0.12)] border border-[oklch(0.78_0.22_152/0.3)] px-2.5 py-1",
    children: [
      e.jsx("span", {
        className:
          "w-1.5 h-1.5 rounded-full bg-[var(--emerald-glow)] animate-pulse-dot shadow-[0_0_6px_var(--emerald-glow)]",
      }),
      e.jsx("span", {
        className: "text-emerald-glow font-semibold",
        children: t,
      }),
    ],
  });
}
function A({ src: t, label: s }) {
  return e.jsxs("div", {
    className: "flex flex-col items-center gap-1.5 animate-float-y",
    style: { animationDelay: "0.5s" },
    children: [
      e.jsx("div", {
        className:
          "w-14 h-14 sm:w-16 sm:h-16 rounded-2xl glass-card p-2 flex items-center justify-center hover-lift",
        children: e.jsx("img", {
          src: t,
          alt: s,
          className: "w-full h-full object-contain rounded-lg",
        }),
      }),
      e.jsx("span", {
        className:
          "text-[10px] uppercase tracking-wider text-muted-foreground font-semibold",
        children: s,
      }),
    ],
  });
}
function $(t) {
  const {
    broker: s,
    logo: a,
    asset: r,
    time: m,
    onOpenAssets: o,
    onOpenTime: c,
  } = t;
  return e.jsxs("div", {
    className:
      "glass-card rounded-3xl p-5 sm:p-6 relative overflow-hidden hover-lift",
    children: [
      e.jsx("div", {
        className:
          "absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-px bg-gradient-to-r from-transparent via-[var(--emerald-glow)] to-transparent",
      }),
      e.jsxs("div", {
        className: "flex items-center justify-between mb-4",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2.5",
            children: [
              e.jsx("img", {
                src: a,
                alt: "",
                className: "w-9 h-9 rounded-lg object-contain",
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h3", {
                    className: "text-sm font-bold tracking-wide",
                    children:
                      s === "quotex"
                        ? "QUOTEX TERMINAL"
                        : "POCKET OPTION TERMINAL",
                  }),
                  e.jsx("p", {
                    className:
                      "text-[10px] text-muted-foreground uppercase tracking-wider",
                    children: "Institutional Module",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("span", {
            className:
              "inline-flex items-center gap-1.5 text-[10px] font-bold text-emerald-glow",
            children: [
              e.jsx("span", {
                className:
                  "w-1.5 h-1.5 rounded-full bg-[var(--emerald-glow)] animate-pulse-dot",
              }),
              "MARKET PULSE",
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsx(O, {
            label: "Select Market Asset",
            value: r,
            placeholder: "Tap to choose currency pair",
            icon: "📊",
            onClick: o,
          }),
          e.jsx(O, {
            label: "Select Expiry Timeframe",
            value: m,
            placeholder: "Tap to choose duration",
            icon: "⏱",
            onClick: c,
          }),
        ],
      }),
    ],
  });
}
function O({ label: t, value: s, placeholder: a, icon: r, onClick: m }) {
  return e.jsxs("button", {
    onClick: m,
    className:
      "w-full text-left glass-card rounded-2xl p-4 flex items-center gap-3 hover-lift group",
    children: [
      e.jsx("div", {
        className:
          "w-11 h-11 rounded-xl gradient-emerald flex items-center justify-center text-xl flex-shrink-0",
        children: r,
      }),
      e.jsxs("div", {
        className: "flex-1 min-w-0",
        children: [
          e.jsx("p", {
            className:
              "text-[10px] uppercase tracking-wider text-muted-foreground font-semibold",
            children: t,
          }),
          e.jsx("p", {
            className: `text-base font-bold truncate ${s ? "text-emerald-glow" : "text-foreground/60"}`,
            children: s || a,
          }),
        ],
      }),
      e.jsx("span", {
        className:
          "text-muted-foreground group-hover:text-gold-glow transition-colors",
        children: "›",
      }),
    ],
  });
}
function F() {
  return e.jsxs("footer", {
    className: "mt-10 px-4 sm:px-6 pb-6 text-center",
    children: [
      e.jsx("p", {
        className:
          "text-[11px] tracking-[0.25em] text-[var(--gold)]/80 uppercase font-semibold",
        children: "VEERUBOT · PREMIUM SIGNAL INTELLIGENCE",
      }),
      e.jsx("p", {
        className: "text-[10px] text-muted-foreground/60 mt-1",
        children: "Powered by VEERUBOT Intelligence Engine",
      }),
      e.jsxs("div", {
        className: "mt-4 flex flex-wrap justify-center gap-2.5",
        children: [
          e.jsx("a", {
            href: WHATSAPP_URL,
            target: "_blank",
            rel: "noreferrer",
            className:
              "rounded-2xl px-5 py-3 text-xs font-bold tracking-wide glass-card text-emerald-glow hover-lift",
            children: "💬 JOIN WHATSAPP",
          }),
        ],
      }),
    ],
  });
}
function Y({ kind: t, broker: s, market: mkt, currentValue: a, onClose: r, onSelect: m }) {
  const [o, c] = d.useState(""),
    i = d.useMemo(
      () =>
        t === "time"
          ? [
              {
                title:
                  mkt === "live" ? "LIVE TIMEFRAMES (FROM 1M)" : "OTC TIMEFRAMES (FROM 5S)",
                items: mkt === "live" ? PL : P,
              },
            ]
          : mkt === "live"
            ? [
                { title: "LIVE MAJORS", items: C },
                { title: "LIVE CROSSES", items: C2 },
                { title: "LIVE MINORS & EXOTICS", items: C4 },
                { title: "LIVE METALS · CRYPTO · INDICES", items: C3 },
              ]
            : s === "quotex"
              ? [
                  { title: "QUOTEX OTC MARKETS", items: I.map((f) => f + " OTC") },
                  { title: "OTC MAJORS", items: M },
                  { title: "OTC CROSSES", items: R },
                  { title: "OTC MINORS & EXOTICS", items: _ },
                  { title: "OTC COMMODITIES & CRYPTO", items: Z },
                ]
              : [
                  { title: "OTC MAJORS", items: M },
                  { title: "OTC CROSSES", items: R },
                  { title: "OTC MINORS & EXOTICS", items: _ },
                  { title: "OTC COMMODITIES & CRYPTO", items: Z },
                ],
      [t, s, mkt],
    ),
    x = d.useMemo(
      () =>
        i
          .map((u) => ({
            ...u,
            items: u.items.filter((l) =>
              l.toLowerCase().includes(o.toLowerCase()),
            ),
          }))
          .filter((u) => u.items.length > 0),
      [i, o],
    );
  return e.jsxs("div", {
    className:
      "fixed inset-0 z-50 flex items-end sm:items-center justify-center",
    children: [
      e.jsx("div", {
        className:
          "absolute inset-0 bg-black/70 backdrop-blur-md animate-fade-slide",
        onClick: r,
      }),
      e.jsxs("div", {
        className:
          "relative w-full sm:max-w-lg glass-card rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col animate-slide-up",
        children: [
          e.jsxs("div", {
            className:
              "p-5 border-b border-border flex items-center justify-between",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx("h3", {
                    className: "text-base font-bold tracking-wide",
                    children:
                      t === "asset"
                        ? "Select Market Asset"
                        : "Select Timeframe",
                  }),
                  e.jsxs("p", {
                    className:
                      "text-[10px] uppercase tracking-wider text-emerald-glow font-semibold mt-0.5",
                    children: [
                      s === "quotex" ? "Quotex" : "Pocket Option",
                      " Workspace",
                    ],
                  }),
                ],
              }),
              e.jsx("button", {
                onClick: r,
                className:
                  "w-9 h-9 rounded-full glass-card flex items-center justify-center text-lg hover-lift",
                children: "✕",
              }),
            ],
          }),
          t === "asset" &&
            e.jsx("div", {
              className: "px-5 pt-4",
              children: e.jsx("input", {
                value: o,
                onChange: (u) => c(u.target.value),
                placeholder: "🔍 Search assets...",
                className:
                  "w-full bg-input/60 rounded-xl px-4 py-2.5 text-sm outline-none border border-border focus:ring-2 focus:ring-[var(--emerald-glow)]",
              }),
            }),
          e.jsx("div", {
            className: "overflow-y-auto flex-1 p-5 space-y-5",
            children: x.map((u) =>
              e.jsxs(
                "div",
                {
                  children: [
                    e.jsx("h4", {
                      className:
                        "text-[10px] font-bold tracking-[0.2em] text-emerald-glow mb-2.5 uppercase",
                      children: u.title,
                    }),
                    e.jsx("div", {
                      className:
                        t === "time"
                          ? "grid grid-cols-4 gap-2"
                          : "grid grid-cols-2 gap-2",
                      children: u.items.map((l) => {
                        const n = a === l;
                        return e.jsxs(
                          "button",
                          {
                            onClick: () => m(l),
                            className: `relative rounded-xl py-3 px-3 text-sm font-bold tracking-wide transition-all ${n ? "gradient-emerald text-primary-foreground shadow-[0_0_22px_oklch(0.80_0.12_85/0.5)] ring-1 ring-[var(--gold)]" : "glass-card text-foreground/85 hover:text-gold-glow hover-lift"}`,
                            children: [
                              l,
                              n &&
                                e.jsx("span", {
                                  className:
                                    "absolute top-1 right-1.5 text-[10px]",
                                  children: "✓",
                                }),
                            ],
                          },
                          l,
                        );
                      }),
                    }),
                  ],
                },
                u.title,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
const D = [
  "Scanning live candlestick patterns and liquidity volume pools...",
  "Analyzing Price Action...",
  "Detecting Smart Money Flow...",
  "Mapping Liquidity Zones...",
  "Evaluating Momentum Strength...",
  "Confirming Entry Probability...",
];
function W({ asset: t, time: s, onComplete: a }) {
  const [r, m] = d.useState(0),
    [o, c] = d.useState(0),
    [i, x] = d.useState(null);
  return (
    d.useEffect(() => {
      const u = setInterval(() => {
          m((n) => (n >= 100 ? (clearInterval(u), 100) : n + 1.4));
        }, 80),
        l = setInterval(() => c((n) => (n + 1) % D.length), 1400);
      return () => {
        (clearInterval(u), clearInterval(l));
      };
    }, []),
    d.useEffect(() => {
      r >= 100 && i === null && x(3);
    }, [r, i]),
    d.useEffect(() => {
      if (i === null) return;
      if (i === 0) {
        const l = Math.random() > 0.5 ? "BUY" : "SELL",
          n = Math.random() > 0.5 ? 84 : 78;
        setTimeout(() => a(l, n), 600);
        return;
      }
      const u = setTimeout(() => x((l) => (l ?? 1) - 1), 900);
      return () => clearTimeout(u);
    }, [i, a]),
    e.jsxs("div", {
      className:
        "relative z-10 min-h-screen flex flex-col px-4 sm:px-6 py-5 animate-fade-slide",
      children: [
        e.jsxs("div", {
          className:
            "glass-card rounded-2xl px-4 py-3 flex items-center justify-between",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("img", {
                  src: w,
                  alt: "",
                  className:
                    "w-9 h-9 rounded-full object-cover ring-1 ring-[oklch(0.80_0.12_85/0.5)]",
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx("p", { className: "text-xs font-bold", children: t }),
                    e.jsxs("p", {
                      className:
                        "text-[10px] text-emerald-glow uppercase tracking-wider",
                      children: ["Timeframe: ", s],
                    }),
                  ],
                }),
              ],
            }),
            e.jsx(N, { dot: "emerald", children: "SCANNING" }),
          ],
        }),
        e.jsxs("div", {
          className:
            "mt-4 glass-card rounded-3xl p-4 sm:p-5 relative overflow-hidden",
          children: [
            e.jsx("div", { className: "absolute inset-0 grid-bg opacity-40" }),
            e.jsx("div", {
              className:
                "absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-[var(--emerald-glow)] to-transparent animate-scan-line",
            }),
            e.jsxs("div", {
              className: "relative",
              children: [
                e.jsxs("div", {
                  className: "flex justify-between items-center mb-3",
                  children: [
                    e.jsx("span", {
                      className:
                        "text-[10px] uppercase tracking-wider text-muted-foreground font-bold",
                      children: "Live Candlestick Feed",
                    }),
                    e.jsxs("span", {
                      className: "text-xs font-bold text-emerald-glow",
                      children: [
                        "1.",
                        Math.floor(Math.random() * 99999)
                          .toString()
                          .padStart(5, "0"),
                      ],
                    }),
                  ],
                }),
                e.jsx(H, {}),
                e.jsx(K, {}),
                e.jsx(z, {}),
              ],
            }),
          ],
        }),
        e.jsx(Q, {}),
        e.jsxs("div", {
          className: "mt-4 glass-card rounded-2xl p-4",
          children: [
            e.jsx("p", {
              className: "text-xs text-foreground/85 min-h-[1.5em]",
              children: D[o],
            }),
            e.jsx("div", {
              className:
                "mt-3 h-2.5 rounded-full bg-input/60 overflow-hidden relative",
              children: e.jsx("div", {
                className:
                  "h-full gradient-emerald relative transition-all duration-100",
                style: { width: `${Math.min(r, 100)}%` },
                children: e.jsx("div", {
                  className: "absolute inset-0 shine-sweep",
                }),
              }),
            }),
            e.jsxs("p", {
              className:
                "mt-2 text-right text-[10px] font-bold text-emerald-glow",
              children: [Math.min(Math.round(r), 100), "%"],
            }),
          ],
        }),
        e.jsxs("div", {
          className: "mt-4 grid grid-cols-3 gap-2",
          children: [
            e.jsx(k, { title: "DATA POINTS", value: "8,412" }),
            e.jsx(k, { title: "ACCURACY", value: "94.9%" }),
            e.jsx(k, { title: "ODDS RATIO", value: "92%" }),
          ],
        }),
        i !== null &&
          i > 0 &&
          e.jsxs("div", {
            className:
              "fixed inset-0 z-40 flex items-center justify-center pointer-events-none",
            children: [
              e.jsx("div", {
                className: "absolute inset-0 bg-background/70 backdrop-blur-sm",
              }),
              e.jsx(
                "span",
                {
                  className:
                    "relative text-[140px] sm:text-[200px] font-extrabold text-emerald-glow animate-count-burst",
                  children: i,
                },
                i,
              ),
            ],
          }),
      ],
    })
  );
}
function H() {
  const [t, s] = d.useState(() => J(30));
  d.useEffect(() => {
    const i = setInterval(() => {
      s((x) => {
        const l = x[x.length - 1].close + (Math.random() - 0.5) * 8,
          n = l + (Math.random() - 0.5) * 6,
          p = Math.max(n, l) + Math.random() * 4,
          h = Math.min(n, l) - Math.random() * 4;
        return [...x.slice(1), { open: n, close: l, high: p, low: h }];
      });
    }, 600);
    return () => clearInterval(i);
  }, []);
  const a = t.flatMap((i) => [i.high, i.low]),
    r = Math.max(...a),
    m = Math.min(...a),
    o = r - m || 1,
    c = 160;
  return e.jsx("svg", {
    viewBox: "0 0 300 160",
    className: "w-full h-40",
    children: t.map((i, x) => {
      const u = (x / t.length) * 300 + 4,
        l = 300 / t.length - 2,
        n = ((r - i.high) / o) * c,
        p = ((r - i.low) / o) * c,
        h = ((r - i.open) / o) * c,
        g = ((r - i.close) / o) * c,
        j = i.close >= i.open ? "oklch(0.78 0.22 152)" : "oklch(0.65 0.25 22)";
      return e.jsxs(
        "g",
        {
          children: [
            e.jsx("line", {
              x1: u + l / 2,
              x2: u + l / 2,
              y1: n,
              y2: p,
              stroke: j,
              strokeWidth: "1",
            }),
            e.jsx("rect", {
              x: u,
              y: Math.min(h, g),
              width: l,
              height: Math.max(Math.abs(g - h), 1),
              fill: j,
              opacity: "0.9",
            }),
          ],
        },
        x,
      );
    }),
  });
}
function J(t) {
  let s = 100;
  return Array.from({ length: t }, () => {
    const a = s,
      r = s + (Math.random() - 0.5) * 6,
      m = Math.max(a, r) + Math.random() * 3,
      o = Math.min(a, r) - Math.random() * 3;
    return ((s = r), { open: a, close: r, high: m, low: o });
  });
}
function K() {
  const [t, s] = d.useState(() =>
    Array.from({ length: 30 }, () => Math.random()),
  );
  return (
    d.useEffect(() => {
      const a = setInterval(
        () => s((r) => [...r.slice(1), Math.random()]),
        600,
      );
      return () => clearInterval(a);
    }, []),
    e.jsx("div", {
      className: "mt-2 flex items-end gap-0.5 h-10",
      children: t.map((a, r) =>
        e.jsx(
          "div",
          {
            className: "flex-1 rounded-sm",
            style: {
              height: `${a * 100}%`,
              background:
                r % 3 === 0
                  ? "oklch(0.65 0.25 22 / 0.7)"
                  : "oklch(0.78 0.22 152 / 0.7)",
            },
          },
          r,
        ),
      ),
    })
  );
}
function z() {
  const [t, s] = d.useState(0);
  d.useEffect(() => {
    const o = setInterval(() => s((c) => c + 1), 120);
    return () => clearInterval(o);
  }, []);
  const a = Array.from(
      { length: 30 },
      (o, c) => 30 + Math.sin((c + t) * 0.3) * 20 + 20,
    ),
    r = Array.from(
      { length: 30 },
      (o, c) => 30 + Math.cos((c + t) * 0.25) * 15 + 25,
    ),
    m = (o) =>
      o
        .map(
          (c, i) => `${i === 0 ? "M" : "L"}${(i / 29) * 300},${60 - c / 1.5}`,
        )
        .join(" ");
  return e.jsxs("div", {
    className: "mt-2 grid grid-cols-2 gap-2",
    children: [
      e.jsxs("div", {
        className: "glass-card rounded-lg p-2",
        children: [
          e.jsxs("div", {
            className: "flex justify-between text-[9px] mb-1",
            children: [
              e.jsx("span", {
                className: "text-muted-foreground font-bold",
                children: "RSI",
              }),
              e.jsx("span", {
                className: "text-emerald-glow font-bold",
                children: Math.round(a[a.length - 1]),
              }),
            ],
          }),
          e.jsx("svg", {
            viewBox: "0 0 300 60",
            className: "w-full h-10",
            children: e.jsx("path", {
              d: m(a),
              fill: "none",
              stroke: "oklch(0.78 0.22 152)",
              strokeWidth: "1.5",
            }),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "glass-card rounded-lg p-2",
        children: [
          e.jsxs("div", {
            className: "flex justify-between text-[9px] mb-1",
            children: [
              e.jsx("span", {
                className: "text-muted-foreground font-bold",
                children: "MACD",
              }),
              e.jsx("span", {
                className: "text-emerald-glow font-bold",
                children: (r[r.length - 1] / 10).toFixed(2),
              }),
            ],
          }),
          e.jsx("svg", {
            viewBox: "0 0 300 60",
            className: "w-full h-10",
            children: e.jsx("path", {
              d: m(r),
              fill: "none",
              stroke: "oklch(0.7 0.18 200)",
              strokeWidth: "1.5",
            }),
          }),
        ],
      }),
    ],
  });
}
function Q() {
  const t = [
    "EUR/USD ▲ 1.0842",
    "GBP/USD ▼ 1.2715",
    "USD/JPY ▲ 149.32",
    "AUD/USD ▲ 0.6584",
    "USD/CHF ▼ 0.8927",
    "EUR/JPY ▲ 161.85",
  ];
  return e.jsx("div", {
    className: "mt-3 glass-card rounded-xl py-2 overflow-hidden relative",
    children: e.jsx("div", {
      className: "flex gap-8 animate-ticker whitespace-nowrap",
      children: [...t, ...t].map((s, a) =>
        e.jsx(
          "span",
          {
            className: "text-xs font-bold",
            children: e.jsx("span", {
              className: s.includes("▲")
                ? "text-emerald-glow"
                : "text-[var(--crimson)]",
              children: s,
            }),
          },
          a,
        ),
      ),
    }),
  });
}
function k({ title: t, value: s }) {
  return e.jsxs("div", {
    className: "glass-card rounded-xl p-2.5 text-center",
    children: [
      e.jsx("p", {
        className:
          "text-[9px] uppercase tracking-wider text-muted-foreground font-bold",
        children: t,
      }),
      e.jsx("p", {
        className: "text-sm font-extrabold text-emerald-glow mt-0.5",
        children: s,
      }),
    ],
  });
}
function X({ signal: t, onReset: s }) {
  const [a, r] = d.useState(9),
    [m, o] = d.useState(0),
    [c, i] = d.useState(0);
  (d.useEffect(() => {
    if (a <= 0) return;
    const l = setTimeout(() => r((n) => n - 1), 1e3);
    return () => clearTimeout(l);
  }, [a]),
    d.useEffect(() => {
      let l = 0;
      const n = setInterval(() => {
        ((l += 2), l >= t.winRate ? (o(t.winRate), clearInterval(n)) : o(l));
      }, 30);
      return () => clearInterval(n);
    }, [t.winRate]),
    d.useEffect(() => {
      let l = 0;
      const n = setInterval(() => {
        ((l += 1), i(l), l >= 5 && clearInterval(n));
      }, 180);
      return () => clearInterval(n);
    }, []));
  const x = t.dir === "BUY",
    u = (a / 9) * 360;
  return e.jsxs("div", {
    className:
      "relative z-10 min-h-screen flex flex-col px-4 sm:px-6 py-5 animate-fade-slide",
    children: [
      e.jsxs("div", {
        className: "text-center",
        children: [
          e.jsx("p", {
            className:
              "text-xs uppercase tracking-[0.3em] text-muted-foreground",
            children: "Signal for",
          }),
          e.jsxs("h2", {
            className:
              "text-2xl sm:text-3xl font-extrabold text-emerald-glow mt-1",
            children: [t.asset, t.market === "live" ? " (LIVE)" : " (OTC)"],
          }),
          e.jsxs("p", {
            className:
              "text-xs text-emerald-glow/80 mt-1 uppercase tracking-widest",
            children: ["Timeframe: ", t.time],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-7 flex flex-col items-center",
        children: [
          e.jsxs("div", {
            className:
              "relative w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center",
            children: [
              Array.from({ length: 8 }).map((l, n) =>
                e.jsx(
                  "span",
                  {
                    className: `absolute w-1.5 h-1.5 rounded-full ${x ? "bg-[var(--emerald-glow)]" : "bg-[var(--crimson)]"} ${x ? "animate-particle-up" : "animate-particle-down"}`,
                    style: {
                      left: `${15 + n * 10}%`,
                      animationDelay: `${n * 0.25}s`,
                      boxShadow: "0 0 8px currentColor",
                    },
                  },
                  n,
                ),
              ),
              e.jsx("div", {
                className: `absolute inset-0 rounded-full ${x ? "animate-breathe" : "animate-breathe-red"}`,
                style: {
                  background: x
                    ? "radial-gradient(circle, oklch(0.78 0.22 152 / 0.7), oklch(0.5 0.18 152 / 0.2) 60%, transparent 80%)"
                    : "radial-gradient(circle, oklch(0.7 0.26 22 / 0.7), oklch(0.5 0.2 22 / 0.2) 60%, transparent 80%)",
                },
              }),
              e.jsx("div", {
                className:
                  "relative w-32 h-32 sm:w-36 sm:h-36 rounded-full glass-card flex items-center justify-center",
                children: e.jsx("svg", {
                  viewBox: "0 0 24 24",
                  className:
                    "w-20 h-20 text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.6)]",
                  children: x
                    ? e.jsx("path", {
                        d: "M12 4l8 10h-5v6h-6v-6H4z",
                        fill: "currentColor",
                      })
                    : e.jsx("path", {
                        d: "M12 20l-8-10h5V4h6v6h5z",
                        fill: "currentColor",
                      }),
                }),
              }),
            ],
          }),
          e.jsx("h3", {
            className: `mt-5 text-4xl sm:text-5xl font-extrabold tracking-wider ${x ? "text-emerald-glow" : "text-[var(--crimson)]"}`,
            children: x ? "BUY (LONG)" : "SELL (SHORT)",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-6 grid grid-cols-2 gap-3",
        children: [
          e.jsxs("div", {
            className: "glass-card rounded-2xl p-4",
            children: [
              e.jsx("p", {
                className:
                  "text-[10px] uppercase tracking-wider text-muted-foreground font-bold",
                children: "Signal Strength",
              }),
              e.jsx("div", {
                className: "mt-2 flex gap-1.5",
                children: Array.from({ length: 5 }).map((l, n) =>
                  e.jsx(
                    "span",
                    {
                      className: `w-3 h-3 rounded-full transition-all ${n < c ? "bg-[var(--emerald-glow)] shadow-[0_0_8px_var(--emerald-glow)]" : "bg-muted"}`,
                    },
                    n,
                  ),
                ),
              }),
              e.jsxs("p", {
                className: "mt-2 text-lg font-bold",
                children: [c, "/5"],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass-card rounded-2xl p-4",
            children: [
              e.jsx("p", {
                className:
                  "text-[10px] uppercase tracking-wider text-muted-foreground font-bold",
                children: "Win Rate",
              }),
              e.jsxs("p", {
                className: "mt-2 text-3xl font-extrabold text-emerald-glow",
                children: [m, "%"],
              }),
              e.jsx("p", {
                className:
                  "text-[10px] text-emerald-glow/80 uppercase font-bold",
                children: "● Live",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass-card rounded-2xl p-4",
            children: [
              e.jsx("p", {
                className:
                  "text-[10px] uppercase tracking-wider text-muted-foreground font-bold",
                children: "Confidence Score",
              }),
              e.jsxs("p", {
                className: "mt-2 text-2xl font-extrabold",
                children: [
                  x ? "9.2" : "8.8",
                  e.jsx("span", {
                    className: "text-sm text-muted-foreground",
                    children: "/10",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "glass-card rounded-2xl p-4",
            children: [
              e.jsx("p", {
                className:
                  "text-[10px] uppercase tracking-wider text-muted-foreground font-bold",
                children: "Market Sentiment",
              }),
              e.jsx("p", {
                className: `mt-2 text-base font-extrabold ${x ? "text-emerald-glow" : "text-[var(--crimson)]"}`,
                children: x ? "BULLISH" : "BEARISH",
              }),
              e.jsx("p", {
                className:
                  "text-[10px] text-muted-foreground uppercase font-bold",
                children: "Liquidity ✓ Confirmed",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className:
          "mt-5 glass-card rounded-full px-5 py-3 flex items-center gap-3 relative overflow-hidden",
        children: [
          e.jsx("span", {
            className:
              "w-2 h-2 rounded-full bg-[var(--emerald-glow)] animate-pulse-dot shadow-[0_0_8px_var(--emerald-glow)] flex-shrink-0",
          }),
          e.jsx("span", {
            className:
              "text-xs font-bold tracking-wider text-emerald-glow flex-shrink-0",
            children: "● AI PROCESSING",
          }),
          e.jsx("div", {
            className: "flex-1 h-4 flex items-center gap-0.5",
            children: Array.from({ length: 30 }).map((l, n) =>
              e.jsx(
                "span",
                {
                  className: "flex-1 rounded-sm bg-[var(--emerald-glow)]",
                  style: {
                    height: `${30 + Math.abs(Math.sin(n * 0.5 + Date.now() / 200)) * 70}%`,
                    opacity: 0.6,
                  },
                },
                n,
              ),
            ),
          }),
          e.jsx("div", {
            className: "absolute inset-0 shine-sweep pointer-events-none",
          }),
        ],
      }),
      e.jsx("div", {
        className: "mt-5 flex items-center justify-center",
        children: e.jsxs("div", {
          className: "relative w-24 h-24",
          children: [
            e.jsxs("svg", {
              viewBox: "0 0 100 100",
              className: "w-full h-full -rotate-90",
              children: [
                e.jsx("circle", {
                  cx: "50",
                  cy: "50",
                  r: "44",
                  fill: "none",
                  stroke: "oklch(0.3 0.02 250)",
                  strokeWidth: "6",
                }),
                e.jsx("circle", {
                  cx: "50",
                  cy: "50",
                  r: "44",
                  fill: "none",
                  stroke: "var(--emerald-glow)",
                  strokeWidth: "6",
                  strokeLinecap: "round",
                  strokeDasharray: 2 * Math.PI * 44,
                  strokeDashoffset: 2 * Math.PI * 44 * (1 - u / 360),
                  style: {
                    transition: "stroke-dashoffset 1s linear",
                    filter: "drop-shadow(0 0 6px var(--emerald-glow))",
                  },
                }),
              ],
            }),
            e.jsxs("div", {
              className:
                "absolute inset-0 flex flex-col items-center justify-center",
              children: [
                e.jsxs("span", {
                  className: "text-2xl font-extrabold text-emerald-glow",
                  children: [a, "s"],
                }),
                e.jsx("span", {
                  className:
                    "text-[9px] uppercase tracking-wider text-muted-foreground font-bold",
                  children: "Trade Timer",
                }),
              ],
            }),
          ],
        }),
      }),
      e.jsx("button", {
        onClick: s,
        disabled: a > 0,
        className: `mt-6 w-full rounded-2xl py-4 font-extrabold tracking-wider transition-all ${a > 0 ? "bg-muted text-muted-foreground cursor-not-allowed" : "gradient-emerald text-primary-foreground animate-breathe hover-lift shine-sweep relative overflow-hidden"}`,
        children: a > 0 ? `Wait ${a}s for New Signal` : "↻ GENERATE NEW SIGNAL",
      }),
      e.jsxs("div", {
        className: "mt-6 grid grid-cols-3 gap-2 text-center",
        children: [
          e.jsx(S, { label: "AI Core", value: "Online" }),
          e.jsx(S, { label: "Market Feed", value: "Stable" }),
          e.jsx(S, { label: "Signal Engine", value: "Active" }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-6 text-center",
        children: [
          e.jsx("p", {
            className:
              "text-[11px] tracking-[0.25em] text-[var(--gold)]/80 uppercase font-semibold",
            children: "VEERUBOT · PREMIUM SIGNAL INTELLIGENCE",
          }),
          e.jsx("p", {
            className: "text-[10px] text-muted-foreground/60 mt-1",
            children: "Powered by VEERUBOT Intelligence Engine",
          }),
        ],
      }),
    ],
  });
}
function S({ label: t, value: s }) {
  return e.jsxs("div", {
    className: "glass-card rounded-xl py-2 px-2",
    children: [
      e.jsx("p", {
        className:
          "text-[9px] uppercase tracking-wider text-muted-foreground font-bold",
        children: t,
      }),
      e.jsxs("p", {
        className:
          "text-xs font-bold text-emerald-glow flex items-center justify-center gap-1 mt-0.5",
        children: [
          e.jsx("span", {
            className:
              "w-1.5 h-1.5 rounded-full bg-[var(--emerald-glow)] animate-pulse-dot",
          }),
          s,
        ],
      }),
    ],
  });
}
export { ee as VeerApp };
