import { createServerFn } from "@tanstack/react-start";

export type License = {
  id: string;
  license_key: string;
  status: string;
  created_at: string;
  activated_at: string | null;
  expires_at: string | null;
  device_limit: number;
  notes: string;
  last_activity: string | null;
  devices: { id: string; device_id: string; label: string; last_seen: string }[];
};

export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((d: { password: string }) => d)
  .handler(async ({ data }) => {
    const { checkAdminPassword, issueAdminToken } = await import("./license.server");
    if (!checkAdminPassword(data.password)) return { ok: false as const };
    return { ok: true as const, token: issueAdminToken() };
  });

export const adminListLicenses = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const { assertAdminToken, admin } = await import("./license.server");
    assertAdminToken(data.token);
    const db = await admin();
    const { data: rows, error } = await db
      .from("licenses")
      .select("*, license_devices(id, device_id, label, last_seen)")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (rows ?? []).map((r: Record<string, unknown>) => ({
      ...r,
      devices: (r["license_devices"] as unknown[]) ?? [],
    })) as License[];
  });

export const adminCreateLicenses = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      token: string;
      count: number;
      hours: number | null;
      deviceLimit: number;
      notes: string;
    }) => d,
  )
  .handler(async ({ data }) => {
    const { assertAdminToken, admin, generateKey } = await import("./license.server");
    assertAdminToken(data.token);
    const count = Math.min(Math.max(Math.trunc(data.count) || 1, 1), 200);
    const expires =
      data.hours === null ? null : new Date(Date.now() + data.hours * 3600_000).toISOString();
    const rows = Array.from({ length: count }, () => ({
      license_key: generateKey(),
      status: "active",
      expires_at: expires,
      device_limit: Math.max(Math.trunc(data.deviceLimit) || 0, 0),
      notes: (data.notes ?? "").slice(0, 300),
    }));
    const db = await admin();
    const { data: created, error } = await db.from("licenses").insert(rows).select("license_key");
    if (error) throw new Error(error.message);
    return { keys: (created ?? []).map((r: { license_key: string }) => r.license_key) };
  });

export const adminUpdateLicense = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      token: string;
      id: string;
      action:
        | "activate"
        | "suspend"
        | "revoke"
        | "delete"
        | "extend"
        | "setExpiry"
        | "lifetime"
        | "setDeviceLimit"
        | "setNotes"
        | "resetDevices"
        | "unbindDevice";
      hours?: number;
      expiresAt?: string | null;
      deviceLimit?: number;
      notes?: string;
      deviceRowId?: string;
    }) => d,
  )
  .handler(async ({ data }) => {
    const { assertAdminToken, admin } = await import("./license.server");
    assertAdminToken(data.token);
    const db = await admin();
    const patch: {
      status?: string;
      expires_at?: string | null;
      device_limit?: number;
      notes?: string;
    } = {};

    switch (data.action) {
      case "delete": {
        const { error } = await db.from("licenses").delete().eq("id", data.id);
        if (error) throw new Error(error.message);
        return { ok: true };
      }
      case "resetDevices": {
        const { error } = await db.from("license_devices").delete().eq("license_id", data.id);
        if (error) throw new Error(error.message);
        return { ok: true };
      }
      case "unbindDevice": {
        const { error } = await db
          .from("license_devices")
          .delete()
          .eq("license_id", data.id)
          .eq("id", data.deviceRowId ?? "");
        if (error) throw new Error(error.message);
        return { ok: true };
      }
      case "activate":
        patch["status"] = "active";
        break;
      case "suspend":
        patch["status"] = "suspended";
        break;
      case "revoke":
        patch["status"] = "revoked";
        break;
      case "lifetime":
        patch["expires_at"] = null;
        break;
      case "setExpiry":
        patch["expires_at"] = data.expiresAt ?? null;
        break;
      case "extend": {
        const { data: row } = await db
          .from("licenses")
          .select("expires_at")
          .eq("id", data.id)
          .maybeSingle();
        const base =
          row?.expires_at && new Date(row.expires_at).getTime() > Date.now()
            ? new Date(row.expires_at).getTime()
            : Date.now();
        patch["expires_at"] = new Date(base + (data.hours ?? 0) * 3600_000).toISOString();
        break;
      }
      case "setDeviceLimit":
        patch["device_limit"] = Math.max(Math.trunc(data.deviceLimit ?? 1), 0);
        break;
      case "setNotes":
        patch["notes"] = (data.notes ?? "").slice(0, 300);
        break;
    }

    const { error } = await db.from("licenses").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Public: the only valid public license key is MUGHAL. */
export const verifyLicenseKey = createServerFn({ method: "POST" })
  .inputValidator((d: { key: string; deviceId: string }) => d)
  .handler(async ({ data }) => {
    const key = (data.key ?? "").trim();
    if (key !== "MUGHAL") return { ok: false as const, reason: "INVALID KEY" };
    return { ok: true as const, expiresAt: null };
  });
