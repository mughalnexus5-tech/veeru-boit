import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

export type AdminClaim = { exp: number };

function secret(): string {
  const s = process.env["ADMIN_TOKEN_SECRET"];
  if (!s) throw new Error("Admin token secret is not configured");
  return s;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issueAdminToken(hours = 12): string {
  const payload = String(Date.now() + hours * 3600_000);
  return `${payload}.${sign(payload)}`;
}

export function assertAdminToken(token: unknown): void {
  if (typeof token !== "string" || !token.includes(".")) throw new Error("Unauthorized");
  const [payload, mac] = token.split(".");
  const expected = sign(payload ?? "");
  const a = Buffer.from(mac ?? "");
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) throw new Error("Unauthorized");
  if (Number(payload) < Date.now()) throw new Error("Session expired");
}

export function checkAdminPassword(input: unknown): boolean {
  const expected = process.env["ADMIN_PANEL_PASSWORD"] ?? "";
  if (typeof input !== "string" || expected.length === 0) return false;
  const a = createHmac("sha256", secret()).update(input).digest();
  const b = createHmac("sha256", secret()).update(expected).digest();
  return timingSafeEqual(a, b);
}

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateKey(): string {
  const block = (n: number) =>
    Array.from(randomBytes(n))
      .map((b) => ALPHABET[b % ALPHABET.length])
      .join("");
  return `VEERU-${block(4)}-${block(4)}-${block(4)}`;
}

export async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}
