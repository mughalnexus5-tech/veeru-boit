import { createFileRoute } from "@tanstack/react-router";
// @ts-expect-error - verbatim source pasted from the original site bundle
import { VeerApp } from "../veer-app.jsx";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VEERUBOT — AI Trading Signals for Quotex & Pocket Option" },
      {
        name: "description",
        content:
          "VEERUBOT is a premium AI signal engine for binary options on Quotex and Pocket Option. Real-time OTC and live market signals from 5 seconds to 4 hours, with VIP license access.",
      },
      {
        name: "keywords",
        content:
          "VEERUBOT, binary options signals, Quotex signals, Pocket Option signals, OTC signals, AI trading bot, live market signals",
      },
      { property: "og:url", content: "https://veerubot.com/" },
      { property: "og:title", content: "VEERUBOT — AI Trading Signals for Quotex & Pocket Option" },
      {
        property: "og:description",
        content:
          "Premium AI signal engine for OTC and live binary options markets. Accurate BUY/SELL signals with VIP license access.",
      },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "VEERUBOT" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "VEERUBOT — AI Trading Signals" },
      {
        name: "twitter:description",
        content: "Premium AI signal engine for OTC and live binary options markets.",
      },
      { property: "og:image", content: "https://i.postimg.cc/YCWv6W3G/588252-modified.png" },
      { name: "twitter:image", content: "https://i.postimg.cc/YCWv6W3G/588252-modified.png" },
    ],
    links: [{ rel: "canonical", href: "https://veerubot.com/" }],
  }),

  component: VeerApp,
});
