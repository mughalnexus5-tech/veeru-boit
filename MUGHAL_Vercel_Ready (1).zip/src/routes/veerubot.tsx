import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useState } from "react";

import logoAsset from "@/assets/veerubot-logo.png.asset.json";
import {
  adminCreateLicenses,
  adminListLicenses,
  adminLogin,
  adminUpdateLicense,
  type License,
} from "@/lib/license.functions";

export const Route = createFileRoute("/veerubot")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "VEERUBOT — Admin Panel" },
      { name: "description", content: "Private license management console for VEERUBOT." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "VEERUBOT — Admin Panel" },
      { property: "og:description", content: "Private license management console." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPanel,
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center p-6 text-center">
      <p className="text-sm text-[var(--crimson)]">{error.message}</p>
    </div>
  ),
});

const TOKEN_KEY = "veerubot_admin_token";

const DURATIONS: { label: string; hours: number | null }[] = [
  { label: "1 Day", hours: 24 },
  { label: "7 Days", hours: 24 * 7 },
  { label: "30 Days", hours: 24 * 30 },
  { label: "90 Days", hours: 24 * 90 },
  { label: "6 Months", hours: 24 * 182 },
  { label: "1 Year", hours: 24 * 365 },
  { label: "Lifetime", hours: null },
];

const DEVICE_OPTIONS = [1, 2, 3, 5, 10, 0];

function remaining(expires: string | null): string {
  if (!expires) return "Lifetime";
  const ms = new Date(expires).getTime() - Date.now();
  if (ms <= 0) return "Expired";
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return d > 0 ? `${d}d ${h}h` : h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function effectiveStatus(l: License): string {
  if (l.status !== "active") return l.status;
  if (l.expires_at && new Date(l.expires_at).getTime() < Date.now()) return "expired";
  return "active";
}

const STATUS_STYLE: Record<string, string> = {
  active: "bg-primary/15 text-emerald-glow ring-1 ring-primary/40",
  suspended: "bg-yellow-500/15 text-yellow-400 ring-1 ring-yellow-500/40",
  revoked: "bg-[var(--crimson)]/15 text-[var(--crimson)] ring-1 ring-[var(--crimson)]/40",
  expired: "bg-muted text-muted-foreground ring-1 ring-border",
};

function fmt(v: string | null): string {
  return v ? new Date(v).toLocaleString() : "—";
}

function AdminPanel() {
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    setToken(sessionStorage.getItem(TOKEN_KEY));
  }, []);

  if (!token) return <Login onToken={(t) => (sessionStorage.setItem(TOKEN_KEY, t), setToken(t))} />;
  return (
    <Dashboard
      token={token}
      onLogout={() => {
        sessionStorage.removeItem(TOKEN_KEY);
        setToken(null);
      }}
    />
  );
}

function Login({ onToken }: { onToken: (t: string) => void }) {
  const login = useServerFn(adminLogin);
  const [pw, setPw] = useState("");
  const [state, setState] = useState<"idle" | "busy" | "error">("idle");

  async function submit() {
    setState("busy");
    const res = await login({ data: { password: pw } });
    if (res.ok && res.token) onToken(res.token);
    else setState("error");
  }

  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-5 animate-fade-slide">
      <div
        className={`w-full max-w-sm glass-card rounded-3xl p-8 ${state === "error" ? "animate-shake" : ""}`}
      >
        <div className="flex flex-col items-center">
          <img src={logoAsset.url} alt="VEERUBOT" className="w-24 h-24 rounded-full object-cover" />
          <h1 className="mt-5 text-xl font-bold tracking-tight">VEERUBOT Admin</h1>
          <p className="mt-1 text-[10px] uppercase tracking-[0.3em] text-emerald-glow font-semibold">
            Restricted Console
          </p>
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="Admin password"
            className="mt-7 w-full bg-input/60 rounded-2xl px-5 py-4 text-sm outline-none border border-border focus:ring-2 focus:ring-[var(--emerald-glow)]"
          />
          {state === "error" && (
            <p className="mt-3 text-xs font-semibold text-[var(--crimson)]">⚠ ACCESS DENIED</p>
          )}
          <button
            onClick={submit}
            disabled={state === "busy"}
            className="mt-5 w-full rounded-2xl gradient-emerald text-primary-foreground font-bold py-4 tracking-wide hover-lift disabled:opacity-60"
          >
            {state === "busy" ? "VERIFYING..." : "ENTER ADMIN PANEL"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const list = useServerFn(adminListLicenses);
  const create = useServerFn(adminCreateLicenses);
  const update = useServerFn(adminUpdateLicense);

  const [rows, setRows] = useState<License[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [open, setOpen] = useState<string | null>(null);

  const [duration, setDuration] = useState<string>("30 Days");
  const [customDays, setCustomDays] = useState("0");
  const [customHours, setCustomHours] = useState("0");
  const [deviceLimit, setDeviceLimit] = useState(1);
  const [customDevices, setCustomDevices] = useState("");
  const [count, setCount] = useState("1");
  const [notes, setNotes] = useState("");
  const [lastKeys, setLastKeys] = useState<string[]>([]);

  const refresh = useCallback(async () => {
    try {
      setRows(await list({ data: { token } }));
      setErr(null);
    } catch (e) {
      const m = e instanceof Error ? e.message : "Failed to load licenses";
      setErr(m);
      if (m.includes("Unauthorized") || m.includes("expired")) onLogout();
    }
  }, [list, token, onLogout]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function act(id: string, action: Parameters<typeof update>[0]["data"]["action"], extra = {}) {
    setBusy(true);
    try {
      await update({ data: { token, id, action, ...extra } });
      await refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Action failed");
    }
    setBusy(false);
  }

  async function generate() {
    setBusy(true);
    try {
      let hours: number | null;
      if (duration === "Custom") {
        hours = (Number(customDays) || 0) * 24 + (Number(customHours) || 0);
        if (hours <= 0) hours = 24;
      } else {
        hours = DURATIONS.find((d) => d.label === duration)?.hours ?? 24;
      }
      const res = await create({
        data: {
          token,
          count: Number(count) || 1,
          hours,
          deviceLimit: customDevices ? Number(customDevices) || 1 : deviceLimit,
          notes,
        },
      });
      setLastKeys(res.keys);
      await refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not generate licenses");
    }
    setBusy(false);
  }

  const filtered = useMemo(
    () =>
      rows.filter((r) => {
        const s = effectiveStatus(r);
        if (filter !== "all" && s !== filter) return false;
        const q = search.trim().toLowerCase();
        return !q || r.license_key.toLowerCase().includes(q) || r.notes.toLowerCase().includes(q);
      }),
    [rows, filter, search],
  );

  const stats = useMemo(() => {
    const by = (s: string) => rows.filter((r) => effectiveStatus(r) === s).length;
    return [
      { label: "Total", value: rows.length },
      { label: "Active", value: by("active") },
      { label: "Suspended", value: by("suspended") },
      { label: "Expired", value: by("expired") },
      { label: "Revoked", value: by("revoked") },
      { label: "Devices", value: rows.reduce((a, r) => a + r.devices.length, 0) },
    ];
  }, [rows]);

  return (
    <div className="relative z-10 min-h-screen px-4 sm:px-6 py-6 animate-fade-slide">
      <header className="glass-card rounded-3xl p-5 flex flex-wrap items-center gap-4 justify-between">
        <div className="flex items-center gap-3">
          <img src={logoAsset.url} alt="VEERUBOT" className="w-12 h-12 rounded-full object-cover" />
          <div>
            <h1 className="text-lg font-bold tracking-tight">VEERUBOT Admin Panel</h1>
            <p className="text-[10px] uppercase tracking-[0.25em] text-emerald-glow font-semibold">
              License &amp; Device Management
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => void refresh()}
            className="rounded-xl glass-card px-4 py-2.5 text-xs font-bold hover-lift"
          >
            ⟳ REFRESH
          </button>
          <button
            onClick={onLogout}
            className="rounded-xl px-4 py-2.5 text-xs font-bold bg-[var(--crimson)]/15 text-[var(--crimson)] ring-1 ring-[var(--crimson)]/40"
          >
            LOG OUT
          </button>
        </div>
      </header>

      {err && (
        <p className="mt-4 glass-card rounded-2xl p-4 text-xs text-[var(--crimson)]">{err}</p>
      )}

      <section className="mt-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="glass-card rounded-2xl p-4">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{s.label}</p>
            <p className="mt-1 text-2xl font-extrabold text-emerald-glow">{s.value}</p>
          </div>
        ))}
      </section>

      <section className="mt-5 glass-card rounded-3xl p-5">
        <h2 className="text-sm font-bold tracking-wide">Generate Licenses</h2>
        <div className="mt-4 flex flex-wrap gap-2">
          {[...DURATIONS.map((d) => d.label), "Custom"].map((label) => (
            <button
              key={label}
              onClick={() => setDuration(label)}
              className={`rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
                duration === label
                  ? "gradient-emerald text-primary-foreground"
                  : "glass-card text-foreground/80 hover:text-emerald-glow"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        {duration === "Custom" && (
          <div className="mt-3 grid grid-cols-2 gap-3 max-w-sm">
            <label className="text-xs text-muted-foreground">
              Days
              <input
                value={customDays}
                onChange={(e) => setCustomDays(e.target.value)}
                className="mt-1 w-full bg-input/60 rounded-xl px-3 py-2 text-sm text-foreground border border-border outline-none"
              />
            </label>
            <label className="text-xs text-muted-foreground">
              Hours
              <input
                value={customHours}
                onChange={(e) => setCustomHours(e.target.value)}
                className="mt-1 w-full bg-input/60 rounded-xl px-3 py-2 text-sm text-foreground border border-border outline-none"
              />
            </label>
          </div>
        )}

        <p className="mt-5 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          Device limit
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {DEVICE_OPTIONS.map((n) => (
            <button
              key={n}
              onClick={() => {
                setDeviceLimit(n);
                setCustomDevices("");
              }}
              className={`rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
                deviceLimit === n && !customDevices
                  ? "gradient-emerald text-primary-foreground"
                  : "glass-card text-foreground/80 hover:text-emerald-glow"
              }`}
            >
              {n === 0 ? "Unlimited" : `${n} Device${n > 1 ? "s" : ""}`}
            </button>
          ))}
          <input
            value={customDevices}
            onChange={(e) => setCustomDevices(e.target.value)}
            placeholder="Custom"
            className="w-24 bg-input/60 rounded-xl px-3 py-2.5 text-xs border border-border outline-none"
          />
        </div>

        <div className="mt-5 grid sm:grid-cols-3 gap-3">
          <label className="text-xs text-muted-foreground">
            How many licenses
            <input
              value={count}
              onChange={(e) => setCount(e.target.value)}
              className="mt-1 w-full bg-input/60 rounded-xl px-3 py-2.5 text-sm text-foreground border border-border outline-none"
            />
          </label>
          <label className="sm:col-span-2 text-xs text-muted-foreground">
            Note / label
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Ali — WhatsApp buyer"
              className="mt-1 w-full bg-input/60 rounded-xl px-3 py-2.5 text-sm text-foreground border border-border outline-none"
            />
          </label>
        </div>

        <button
          onClick={() => void generate()}
          disabled={busy}
          className="mt-5 rounded-2xl gradient-emerald text-primary-foreground font-bold px-6 py-3.5 text-sm tracking-wide hover-lift disabled:opacity-60"
        >
          ⚡ GENERATE
        </button>

        {lastKeys.length > 0 && (
          <div className="mt-4 rounded-2xl bg-input/50 border border-border p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="text-[10px] uppercase tracking-[0.2em] text-emerald-glow font-bold">
                New keys ({lastKeys.length})
              </p>
              <button
                onClick={() => void navigator.clipboard.writeText(lastKeys.join("\n"))}
                className="text-xs font-bold text-emerald-glow"
              >
                COPY ALL
              </button>
            </div>
            <pre className="mt-2 text-xs whitespace-pre-wrap break-all text-foreground/90">
              {lastKeys.join("\n")}
            </pre>
          </div>
        )}
      </section>

      <section className="mt-5 glass-card rounded-3xl p-5">
        <div className="flex flex-wrap gap-3 items-center justify-between">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="🔍 Search key or note..."
            className="flex-1 min-w-[200px] bg-input/60 rounded-xl px-4 py-2.5 text-sm border border-border outline-none"
          />
          <div className="flex flex-wrap gap-2">
            {["all", "active", "suspended", "expired", "revoked"].map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`rounded-xl px-3.5 py-2 text-xs font-bold uppercase tracking-wide ${
                  filter === s
                    ? "gradient-emerald text-primary-foreground"
                    : "glass-card text-foreground/75"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-5 space-y-3">
          {filtered.length === 0 && (
            <p className="text-xs text-muted-foreground py-6 text-center">No licenses found.</p>
          )}
          {filtered.map((l) => {
            const st = effectiveStatus(l);
            const isOpen = open === l.id;
            return (
              <div key={l.id} className="rounded-2xl border border-border bg-input/30 p-4">
                <div className="flex flex-wrap items-center gap-3 justify-between">
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-bold break-all">{l.license_key}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      {remaining(l.expires_at)} left · {l.devices.length}/
                      {l.device_limit === 0 ? "∞" : l.device_limit} devices
                      {l.notes ? ` · ${l.notes}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${STATUS_STYLE[st]}`}
                    >
                      {st}
                    </span>
                    <button
                      onClick={() => void navigator.clipboard.writeText(l.license_key)}
                      className="rounded-lg glass-card px-3 py-1.5 text-[11px] font-bold"
                    >
                      COPY
                    </button>
                    <button
                      onClick={() => setOpen(isOpen ? null : l.id)}
                      className="rounded-lg glass-card px-3 py-1.5 text-[11px] font-bold"
                    >
                      {isOpen ? "HIDE" : "MANAGE"}
                    </button>
                  </div>
                </div>

                {isOpen && (
                  <div className="mt-4 border-t border-border pt-4 space-y-4">
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-[11px]">
                      <Detail label="Created" value={fmt(l.created_at)} />
                      <Detail label="Activated" value={fmt(l.activated_at)} />
                      <Detail
                        label="Expires"
                        value={l.expires_at ? fmt(l.expires_at) : "Lifetime"}
                      />
                      <Detail label="Last activity" value={fmt(l.last_activity)} />
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Act onClick={() => act(l.id, "activate")} busy={busy}>
                        Activate
                      </Act>
                      <Act onClick={() => act(l.id, "suspend")} busy={busy}>
                        Suspend
                      </Act>
                      <Act onClick={() => act(l.id, "revoke")} busy={busy}>
                        Revoke
                      </Act>
                      <Act onClick={() => act(l.id, "extend", { hours: 24 })} busy={busy}>
                        +1 Day
                      </Act>
                      <Act onClick={() => act(l.id, "extend", { hours: 24 * 30 })} busy={busy}>
                        +30 Days
                      </Act>
                      <Act onClick={() => act(l.id, "lifetime")} busy={busy}>
                        Lifetime
                      </Act>
                      <Act onClick={() => act(l.id, "resetDevices")} busy={busy}>
                        Reset devices
                      </Act>
                      <Act
                        danger
                        busy={busy}
                        onClick={() => {
                          if (confirm(`Delete license ${l.license_key}? This cannot be undone.`))
                            void act(l.id, "delete");
                        }}
                      >
                        Delete
                      </Act>
                    </div>

                    <div className="grid sm:grid-cols-3 gap-3">
                      <InlineEdit
                        label="Set expiry date"
                        type="datetime-local"
                        initial=""
                        onSave={(v) =>
                          act(l.id, "setExpiry", {
                            expiresAt: v ? new Date(v).toISOString() : null,
                          })
                        }
                      />
                      <InlineEdit
                        label="Device limit (0 = unlimited)"
                        initial={String(l.device_limit)}
                        onSave={(v) => act(l.id, "setDeviceLimit", { deviceLimit: Number(v) || 0 })}
                      />
                      <InlineEdit
                        label="Note"
                        initial={l.notes}
                        onSave={(v) => act(l.id, "setNotes", { notes: v })}
                      />
                    </div>

                    <div>
                      <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                        Bound devices
                      </p>
                      {l.devices.length === 0 ? (
                        <p className="mt-2 text-xs text-muted-foreground">No devices bound yet.</p>
                      ) : (
                        <ul className="mt-2 space-y-2">
                          {l.devices.map((d) => (
                            <li
                              key={d.id}
                              className="flex items-center justify-between gap-3 rounded-xl bg-input/50 px-3 py-2"
                            >
                              <span className="font-mono text-[11px] break-all">
                                {d.device_id}
                                <span className="text-muted-foreground"> · {fmt(d.last_seen)}</span>
                              </span>
                              <button
                                onClick={() => act(l.id, "unbindDevice", { deviceRowId: d.id })}
                                className="rounded-lg px-3 py-1.5 text-[11px] font-bold bg-[var(--crimson)]/15 text-[var(--crimson)]"
                              >
                                UNBIND
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-input/50 px-3 py-2">
      <p className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-semibold">{value}</p>
    </div>
  );
}

function Act({
  children,
  onClick,
  busy,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  busy: boolean;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={busy}
      className={`rounded-xl px-3.5 py-2 text-[11px] font-bold tracking-wide disabled:opacity-50 ${
        danger
          ? "bg-[var(--crimson)]/15 text-[var(--crimson)] ring-1 ring-[var(--crimson)]/40"
          : "glass-card text-foreground/85 hover:text-emerald-glow"
      }`}
    >
      {children}
    </button>
  );
}

function InlineEdit({
  label,
  initial,
  onSave,
  type = "text",
}: {
  label: string;
  initial: string;
  onSave: (v: string) => void;
  type?: string;
}) {
  const [v, setV] = useState(initial);
  return (
    <label className="text-[11px] text-muted-foreground">
      {label}
      <span className="mt-1 flex gap-2">
        <input
          type={type}
          value={v}
          onChange={(e) => setV(e.target.value)}
          className="flex-1 min-w-0 bg-input/60 rounded-xl px-3 py-2 text-xs text-foreground border border-border outline-none"
        />
        <button
          onClick={() => onSave(v)}
          className="rounded-xl gradient-emerald text-primary-foreground px-3 py-2 text-[11px] font-bold"
        >
          SAVE
        </button>
      </span>
    </label>
  );
}
