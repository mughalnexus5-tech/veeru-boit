# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS


## Vercel deployment

This repository is configured for TanStack Start on Vercel.

1. Push this folder to a GitHub repository.
2. In Vercel, import that GitHub repository.
3. Keep the detected framework as **TanStack Start** and deploy.
4. The public license key is **MUGHAL**.
5. The license screen links only to the WhatsApp channel.

No `.env` file is included in this repository. Do not commit private Supabase/service-role credentials.
